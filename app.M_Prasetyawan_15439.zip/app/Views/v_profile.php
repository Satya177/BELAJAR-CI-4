<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman profile <br>
<?= $this->endSection() ?>