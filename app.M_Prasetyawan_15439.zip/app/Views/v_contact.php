<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
Ini halaman contact <br>
<?= $this->endSection() ?>